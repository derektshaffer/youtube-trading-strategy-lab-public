"""Ingest one compact desktop cloud request into the authoritative library."""

from __future__ import annotations

import argparse
from typing import Any

from cloud_research_worker import build_store, env, persist_store
from hybrid_runtime.bridge_ingest import prepare_profit_first_bridge
from hybrid_runtime.bridge_status import (
    BridgeStatusDocument,
    BridgeStatusError,
    GitHubBridgeStatusStore,
)


def build_bridge_store() -> GitHubBridgeStatusStore:
    return GitHubBridgeStatusStore(
        env("GITHUB_BACKUP_REPOSITORY"),
        env("GITHUB_BACKUP_TOKEN"),
        branch=env("GITHUB_BACKUP_BRANCH", "main") or "main",
        library_path=env(
            "GITHUB_BACKUP_PATH",
            "trading-intelligence-lab/intelligence_library.json",
        ),
    )


def process_bridge_document(
    strategy_store: Any,
    bridge_store: GitHubBridgeStatusStore,
    document: BridgeStatusDocument,
) -> tuple[BridgeStatusDocument, dict[str, Any] | None]:
    if document.terminal:
        return document, None
    latest = strategy_store.load_latest()
    preparation = prepare_profit_first_bridge(latest, document)
    if preparation.library_changed:
        persist_store(strategy_store, preparation.library)
    updated = bridge_store.update(
        str(document.value.get("bridge_job_id") or ""),
        preparation.status_patch,
    )
    return updated, preparation.remote_job


def process_bridge_job(
    bridge_job_id: str,
    *,
    strategy_store: Any | None = None,
    bridge_store: GitHubBridgeStatusStore | None = None,
) -> tuple[BridgeStatusDocument, dict[str, Any] | None]:
    cloud_store = strategy_store or build_store()
    statuses = bridge_store or build_bridge_store()
    document = statuses.get(bridge_job_id)
    if document is None:
        raise BridgeStatusError(
            f"Desktop cloud request {bridge_job_id} does not exist."
        )
    return process_bridge_document(cloud_store, statuses, document)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bridge-job-id", required=True)
    args = parser.parse_args(argv)
    document, remote = process_bridge_job(str(args.bridge_job_id).strip())
    print(
        "Desktop cloud bridge "
        f"{document.value.get('bridge_job_id')}: {document.status}; "
        f"remote_job_id={str((remote or {}).get('id') or '') or 'none'}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
