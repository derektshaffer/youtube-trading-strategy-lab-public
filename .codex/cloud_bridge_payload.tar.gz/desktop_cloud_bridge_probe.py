"""Lightweight pending-request probe for the scheduled desktop cloud worker.

This script intentionally imports only the standard-library bridge status client,
so an hourly recovery check does not install the full trading stack when there is
no desktop job to run.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Any

from hybrid_runtime.bridge_status import (
    BridgeStatusDocument,
    GitHubBridgeStatusStore,
)


def env(name: str, default: str = "") -> str:
    return str(os.environ.get(name) or default).strip()


def build_bridge_store() -> GitHubBridgeStatusStore:
    return GitHubBridgeStatusStore(
        env("GITHUB_BACKUP_REPOSITORY"),
        env("GITHUB_BACKUP_TOKEN"),
        branch=env("GITHUB_BACKUP_BRANCH", "main") or "main",
        library_path=env(
            "GITHUB_BACKUP_PATH",
            "trading-intelligence-lab/intelligence_library.json",
        ),
    )


def choose_pending(
    store: GitHubBridgeStatusStore,
    *,
    bridge_job_id: str = "",
    scan_limit: int = 100,
) -> BridgeStatusDocument | None:
    exact = str(bridge_job_id or "").strip()
    if exact:
        document = store.get(exact)
        return document if document is not None and not document.terminal else None
    documents = [
        document
        for document in store.list_documents(
            limit=max(1, min(1000, int(scan_limit)))
        )
        if not document.terminal
    ]
    documents.sort(
        key=lambda document: str(document.value.get("created_at") or "")
    )
    return documents[0] if documents else None


def write_outputs(values: dict[str, Any]) -> None:
    output_path = str(os.environ.get("GITHUB_OUTPUT") or "").strip()
    lines = [f"{key}={str(value).lower() if isinstance(value, bool) else value}" for key, value in values.items()]
    if output_path:
        path = Path(output_path).expanduser().resolve()
        with path.open("a", encoding="utf-8") as handle:
            handle.write("\n".join(lines) + "\n")
    for line in lines:
        print(line, flush=True)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bridge-job-id", default="")
    parser.add_argument("--scan-limit", type=int, default=100)
    args = parser.parse_args(argv)
    document = choose_pending(
        build_bridge_store(),
        bridge_job_id=str(args.bridge_job_id or "").strip(),
        scan_limit=args.scan_limit,
    )
    bridge_job_id = (
        str(document.value.get("bridge_job_id") or "")
        if document is not None
        else ""
    )
    write_outputs(
        {
            "should_run": bool(bridge_job_id),
            "bridge_job_id": bridge_job_id,
        }
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
