from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from hybrid_runtime.bridge_ingest import prepare_profit_first_bridge
from hybrid_runtime.bridge_status import (
    BridgeStatusDocument,
    GitHubBridgeStatusStore,
    bridge_directory_for_library_path,
)
from hybrid_runtime.cloud_bridge import (
    CloudBridgeCoordinator,
    CloudBridgeTransientError,
    CloudBridgeWorker,
    compact_bridge_result,
    profit_first_bridge_id,
)
from hybrid_runtime.contracts import ExecutionTarget, JobRequest, JobStatus
from hybrid_runtime.github_actions import dispatch_workflow
from hybrid_runtime.storage import HybridStore


def bridge_document(
    *,
    status: str,
    bridge_job_id: str = "pf-1234567890abcdef1234567890ab",
    progress: float = 0.1,
    cancel_requested: bool = False,
    remote_job_id: str = "",
    owns_remote_job: bool = True,
) -> BridgeStatusDocument:
    return BridgeStatusDocument(
        {
            "version": 1,
            "bridge_job_id": bridge_job_id,
            "kind": "profit_first_validation",
            "status": status,
            "stage": (
                "cloud_validation_running" if status == "running" else status
            ),
            "progress": progress,
            "message": f"remote {status}",
            "cancel_requested": cancel_requested,
            "remote_job_id": remote_job_id,
            "strategy_ids": ["strategy-a"],
            "owns_remote_job": owns_remote_job,
            "attached_to_existing_job": not owns_remote_job,
        },
        "a" * 40,
    )




class MemoryBridgeStatusStore(GitHubBridgeStatusStore):
    def __init__(self, document: BridgeStatusDocument) -> None:
        self.current = document

    def get(self, _job_id: str):
        return self.current

    def _put(self, _job_id: str, value: dict, *, sha: str = ""):
        self.current = BridgeStatusDocument(dict(value), "e" * 40)
        return self.current


class FakeStatusStore:
    def __init__(self, client: "FakeClient") -> None:
        self.client = client

    def update(self, _bridge_id: str, patch: dict):
        value = dict(self.client.document.value)
        value.update(patch)
        self.client.document = BridgeStatusDocument(value, "b" * 40)
        return self.client.document


class FakeClient:
    def __init__(self, document: BridgeStatusDocument) -> None:
        self.document = document
        self.status_store = FakeStatusStore(self)
        self.ensure_calls = 0
        self.cancel_calls = 0
        self.detach_calls = 0
        self.cancel_error: BaseException | None = None

    def ensure(self, _job):
        self.ensure_calls += 1
        return self.document

    def get(self, _bridge_id: str):
        return self.document

    def cancel(self, _bridge_id: str):
        self.cancel_calls += 1
        if self.cancel_error is not None:
            error = self.cancel_error
            self.cancel_error = None
            raise error
        value = dict(self.document.value)
        value["cancel_requested"] = True
        self.document = BridgeStatusDocument(value, "c" * 40)
        return self.document

    def detach(self, _bridge_id: str):
        self.detach_calls += 1
        value = dict(self.document.value)
        value.update(
            {
                "status": "cancelled",
                "stage": "tracking_detached",
                "outcome": "tracking_detached",
                "cancel_requested": False,
            }
        )
        self.document = BridgeStatusDocument(value, "d" * 40)
        return self.document


def create_cloud_job(
    store: HybridStore,
    *,
    queue_status: str = "ready",
    idempotency_key: str = "desktop-cloud-test",
):
    request = JobRequest(
        job_type="strategy.profit_first_validation",
        payload={
            "expected_dedupe_key": "batch-key",
            "strategy_ids": ["strategy-a"],
            "continue_after_app_exit": True,
            "profit_first_queue_status": queue_status,
        },
        requested_target=ExecutionTarget.CLOUD,
        idempotency_key=idempotency_key,
    )
    job, created = store.create_or_get_job(
        request,
        execution_target=ExecutionTarget.CLOUD,
        route_reason="test cloud route",
    )
    assert created is True
    return job


def test_cloud_bridge_releases_waiting_job_and_reconnects_to_completion(
    tmp_path: Path,
):
    store = HybridStore(tmp_path / "hybrid.sqlite3")
    original = create_cloud_job(store)
    client = FakeClient(
        bridge_document(
            status="queued",
            bridge_job_id=profit_first_bridge_id(original),
            remote_job_id="rq-remote",
        )
    )
    coordinator = CloudBridgeCoordinator(
        store,
        tmp_path,
        client_factory=lambda: client,
    )
    worker = CloudBridgeWorker(
        coordinator,
        worker_id="test-cloud-worker",
        poll_seconds=1,
    )

    assert worker.run_once() is True
    waiting = store.get_job(original.id)
    assert waiting.status == JobStatus.QUEUED
    assert waiting.stage == "queued"
    assert waiting.result["remote_job_id"] == "rq-remote"
    assert client.ensure_calls == 1

    client.document = bridge_document(
        status="complete",
        progress=1.0,
        bridge_job_id=profit_first_bridge_id(original),
        remote_job_id="rq-remote",
    )
    client.document.value["result_ref"] = "autonomous:2026-09-02T00:00:00Z"
    assert worker.run_once() is True

    completed = store.get_job(original.id)
    assert completed.status == JobStatus.COMPLETE
    assert completed.progress == 1.0
    assert completed.result["result_ref"].startswith("autonomous:")
    assert completed.result["research_only"] is True


def test_cloud_cancel_is_written_to_owned_remote_envelope_before_local_terminal(
    tmp_path: Path,
):
    store = HybridStore(tmp_path / "hybrid.sqlite3")
    original = create_cloud_job(store)
    client = FakeClient(
        bridge_document(
            status="queued",
            bridge_job_id=profit_first_bridge_id(original),
            remote_job_id="rq-remote",
            owns_remote_job=True,
        )
    )
    coordinator = CloudBridgeCoordinator(
        store,
        tmp_path,
        client_factory=lambda: client,
    )

    cancelled = coordinator.cancel(original.id)

    assert client.cancel_calls == 1
    assert cancelled.stage == "cloud_cancellation_requested"
    assert cancelled.status == JobStatus.QUEUED

    worker = CloudBridgeWorker(
        coordinator,
        worker_id="test-cloud-worker",
        poll_seconds=1,
    )
    assert worker.run_once() is True
    final = store.get_job(original.id)
    assert final.status == JobStatus.CANCELLED


def test_transient_cancel_is_saved_locally_then_replayed(tmp_path: Path):
    store = HybridStore(tmp_path / "hybrid.sqlite3")
    original = create_cloud_job(store, idempotency_key="cancel-replay")
    client = FakeClient(
        bridge_document(
            status="queued",
            bridge_job_id=profit_first_bridge_id(original),
            remote_job_id="rq-remote",
        )
    )
    client.cancel_error = CloudBridgeTransientError("temporary network failure")
    coordinator = CloudBridgeCoordinator(
        store,
        tmp_path,
        client_factory=lambda: client,
    )

    pending = coordinator.cancel(original.id)
    assert pending.status == JobStatus.QUEUED
    assert pending.stage == "cloud_cancellation_pending"
    assert pending.result["cancel_pending"] is True

    worker = CloudBridgeWorker(
        coordinator,
        worker_id="test-cloud-worker",
        poll_seconds=1,
    )
    assert worker.run_once() is True
    final = store.get_job(original.id)
    assert client.cancel_calls == 2
    assert final.status == JobStatus.CANCELLED


def test_attached_autonomous_job_is_detached_not_cancelled(tmp_path: Path):
    store = HybridStore(tmp_path / "hybrid.sqlite3")
    original = create_cloud_job(
        store,
        queue_status="active",
        idempotency_key="attached-job",
    )
    client = FakeClient(
        bridge_document(
            status="running",
            bridge_job_id=profit_first_bridge_id(original),
            remote_job_id="existing-autonomous-job",
            owns_remote_job=False,
        )
    )
    coordinator = CloudBridgeCoordinator(
        store,
        tmp_path,
        client_factory=lambda: client,
    )

    detached = coordinator.cancel(original.id)

    assert detached.status == JobStatus.CANCELLED
    assert detached.stage == "tracking_detached"
    assert detached.result["outcome"] == "tracking_detached"
    assert client.detach_calls == 1
    assert client.cancel_calls == 0


def test_remote_completion_can_win_cancel_race_from_queued_state(tmp_path: Path):
    store = HybridStore(tmp_path / "hybrid.sqlite3")
    original = create_cloud_job(store, idempotency_key="late-cancel")
    completed_document = bridge_document(
        status="complete",
        progress=1.0,
        bridge_job_id=profit_first_bridge_id(original),
        remote_job_id="rq-complete",
    )
    completed_document.value["result_ref"] = "autonomous:done"
    client = FakeClient(completed_document)
    coordinator = CloudBridgeCoordinator(
        store,
        tmp_path,
        client_factory=lambda: client,
    )

    completed = coordinator.cancel(original.id)

    assert completed.status == JobStatus.COMPLETE
    assert completed.result["result_ref"] == "autonomous:done"


def test_bridge_result_never_contains_credentials():
    document = bridge_document(
        status="running",
        remote_job_id="rq-remote",
    )
    document.value["dispatch"] = {
        "success": True,
        "repository": "owner/repository",
    }
    result = compact_bridge_result(document)
    encoded = repr(result).lower()
    assert "token" not in encoded
    assert "authorization" not in encoded
    assert "secret" not in encoded


def test_bridge_status_directory_is_sibling_of_private_library():
    assert (
        bridge_directory_for_library_path(
            "trading-intelligence-lab/intelligence_library.json"
        )
        == "trading-intelligence-lab/desktop-cloud-jobs"
    )


@patch("profit_first_queue.profit_first_validation_batch")
def test_cloud_ingest_creates_exactly_one_remote_queue_job(batch):
    batch.return_value = {
        "queue_status": "ready",
        "dedupe_key": "automatic-profit-first:abc",
        "strategy_ids": ["strategy-a"],
        "payload": {
            "origin": "automatic_profit_first_validation",
            "strategy_ids": ["strategy-a"],
            "validation_method_version": 7,
        },
    }
    library = {
        "strategies": [],
        "validation_runs": [],
        "research_queue": [],
    }
    document = bridge_document(
        status="queued",
        bridge_job_id="pf-aaaaaaaaaaaaaaaaaaaaaaaaaaaa",
    )
    document.value["expected_dedupe_key"] = "automatic-profit-first:abc"
    document.value["strategy_ids"] = ["strategy-a"]

    first = prepare_profit_first_bridge(library, document)
    assert first.library_changed is True
    assert first.remote_job is not None
    assert (
        first.remote_job["payload"]["desktop_bridge_id"]
        == document.value["bridge_job_id"]
    )
    assert first.status_patch["owns_remote_job"] is True
    assert len(first.library["research_queue"]) == 1

    second = prepare_profit_first_bridge(first.library, document)
    assert second.library_changed is False
    assert second.remote_job["id"] == first.remote_job["id"]
    assert len(second.library["research_queue"]) == 1


def test_cancelled_bridge_never_enters_remote_queue():
    library = {
        "strategies": [],
        "validation_runs": [],
        "research_queue": [],
    }
    document = bridge_document(
        status="queued",
        cancel_requested=True,
        bridge_job_id="pf-bbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    )

    prepared = prepare_profit_first_bridge(library, document)

    assert prepared.remote_job is None
    assert prepared.library_changed is False
    assert prepared.status_patch["status"] == "cancelled"
    assert prepared.library["research_queue"] == []


def test_cancelled_attachment_does_not_mutate_shared_remote_job():
    remote = {
        "id": "shared-job",
        "type": "autonomous_validation",
        "status": "running",
        "dedupe_key": "automatic-profit-first:shared",
        "payload": {"strategy_ids": ["strategy-a"]},
    }
    library = {
        "strategies": [],
        "validation_runs": [],
        "research_queue": [remote],
    }
    document = bridge_document(
        status="running",
        cancel_requested=True,
        bridge_job_id="pf-cccccccccccccccccccccccccccc",
        remote_job_id="shared-job",
        owns_remote_job=False,
    )

    prepared = prepare_profit_first_bridge(library, document)

    assert prepared.library_changed is False
    assert prepared.library["research_queue"][0]["status"] == "running"
    assert prepared.status_patch["status"] == "cancelled"
    assert prepared.status_patch["outcome"] == "tracking_detached"



def test_terminal_cloud_document_is_immutable_after_completion():
    bridge_id = "pf-dddddddddddddddddddddddddddd"
    document = bridge_document(
        status="complete",
        progress=1.0,
        bridge_job_id=bridge_id,
    )
    document.value["message"] = "Strict validation completed."
    document.value["cancel_requested"] = False
    store = MemoryBridgeStatusStore(document)

    after_cancel = store.request_cancel(bridge_id)
    after_failure = store.update(
        bridge_id,
        {
            "status": "failed",
            "message": "late error",
            "error": {"message": "late error"},
        },
    )

    assert after_cancel.status == "complete"
    assert after_cancel.value["message"] == "Strict validation completed."
    assert after_cancel.value["cancel_requested"] is False
    assert after_failure.status == "complete"
    assert "error" not in after_failure.value


def test_workflow_dispatch_rejects_control_characters_before_network_access():
    assert dispatch_workflow(
        "owner/repository",
        "unsafe\ntoken",
        workflow="desktop-cloud-validation.yml",
    )[0] is False
    assert dispatch_workflow(
        "owner/repository",
        "safe-token",
        workflow="desktop-cloud-validation.yml",
        ref="main\nother",
    )[0] is False
    assert dispatch_workflow(
        "owner/repository",
        "safe-token",
        workflow="desktop-cloud-validation.yml",
        inputs={"bridge_job_id": "valid\ninvalid"},
    )[0] is False


def test_desktop_cloud_workflow_has_instant_and_hourly_recovery_paths():
    root = Path(__file__).resolve().parent
    workflow = (
        root / ".github" / "workflows" / "desktop-cloud-validation.yml"
    ).read_text(encoding="utf-8")

    assert 'cron: "27 * * * *"' in workflow
    assert "bridge_job_id:" in workflow
    assert "desktop_cloud_bridge_probe.py" in workflow
    assert "desktop_cloud_research_worker.py" in workflow
    assert "--bridge-job-id" in workflow
    assert "steps.pending.outputs.should_run" in workflow
    assert "group: trading-intelligence-library-writer" in workflow
    assert "GEMINI_API_KEY" not in workflow
